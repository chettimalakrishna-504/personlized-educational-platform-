from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load model and encoders
model = pickle.load(open('model.pkl', 'rb'))
le_interest = pickle.load(open('le_interest.pkl', 'rb'))
le_style = pickle.load(open('le_style.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        interest = request.form['interest']
        style = request.form['style']
        score = float(request.form['score'])

        interest_enc = le_interest.transform([interest])[0]
        style_enc = le_style.transform([style])[0]

        features = np.array([[interest_enc, style_enc, score]])
        prediction = model.predict(features)[0]

        return render_template('result.html', prediction=prediction)
    except Exception as e:
        return render_template('result.html', prediction=f"Error: {e}")

if __name__ == '__main__':
    app.run(debug=True)