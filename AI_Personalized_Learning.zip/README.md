# AI-Powered Personalized Learning Platform

This is a simple **Flask + Machine Learning** project that recommends personalized courses to learners based on their **interests**, **learning style**, and **previous performance**.

## 🚀 Run Locally

1. Install dependencies
   ```bash
   pip install -r requirements.txt
   ```

2. Train the model
   ```bash
   python model.py
   ```

3. Start the web app
   ```bash
   python app.py
   ```

4. Visit http://127.0.0.1:5000

## Example
**Input:**  
- Interest: AI  
- Learning Style: Visual  
- Score: 85  

**Output:**  
→ **Recommended Course:** Deep Learning
