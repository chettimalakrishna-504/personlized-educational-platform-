import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
import pickle

# Sample dataset
data = {
    'interest': ['AI', 'Web', 'AI', 'Data', 'Web', 'Mobile', 'AI', 'Data', 'Cyber', 'Web'],
    'learning_style': ['Visual', 'Auditory', 'Reading', 'Visual', 'Reading', 'Visual', 'Auditory', 'Reading', 'Visual', 'Auditory'],
    'previous_score': [85, 70, 90, 80, 75, 60, 95, 78, 68, 88],
    'recommended_course': ['Deep Learning', 'HTML/CSS', 'Machine Learning', 'Data Analysis', 'JavaScript', 'Flutter', 'AI Ethics', 'Python for Data', 'Cyber Security', 'ReactJS']
}

df = pd.DataFrame(data)

# Encode categorical features
le_interest = LabelEncoder()
le_style = LabelEncoder()

df['interest_enc'] = le_interest.fit_transform(df['interest'])
df['style_enc'] = le_style.fit_transform(df['learning_style'])

X = df[['interest_enc', 'style_enc', 'previous_score']]
y = df['recommended_course']

model = KNeighborsClassifier(n_neighbors=3)
model.fit(X, y)

pickle.dump(model, open('model.pkl', 'wb'))
pickle.dump(le_interest, open('le_interest.pkl', 'wb'))
pickle.dump(le_style, open('le_style.pkl', 'wb'))

print("✅ Model trained and saved successfully!")